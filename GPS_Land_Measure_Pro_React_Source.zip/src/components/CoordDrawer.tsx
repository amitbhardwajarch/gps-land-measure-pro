import { Point } from '../types';

interface Props {
  points: Point[];
  open: boolean;
  selectedPoint: string | null;
  onSelectPoint: (id: string) => void;
  onClose: () => void;
}

export default function CoordDrawer({ points, open, selectedPoint, onSelectPoint, onClose }: Props) {
  if (!open) return null;

  return (
    <div style={{
      position: 'absolute',
      bottom: 0, left: 0, right: 0,
      zIndex: 1100,
      background: 'var(--bg-card)',
      borderTop: '1px solid var(--border-bright)',
      borderRadius: '16px 16px 0 0',
      boxShadow: '0 -4px 30px rgba(0,0,0,0.5)',
      animation: 'slideUp 0.25s ease',
      maxHeight: '45vh',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Handle */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 16px 8px',
        flexShrink: 0,
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: 'var(--primary)', fontSize: 16 }}>📍</span>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 14,
            color: 'var(--primary)',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
          }}>COORDINATES</span>
          <span style={{
            background: 'rgba(0,212,170,0.15)',
            color: 'var(--primary)',
            borderRadius: 6,
            padding: '1px 7px',
            fontSize: 11,
            fontWeight: 700,
            fontFamily: 'var(--font-mono)',
          }}>{points.length}</span>
        </div>
        <button onClick={onClose} style={{
          background: 'none', border: 'none', color: 'var(--text-dim)',
          cursor: 'pointer', fontSize: 20, lineHeight: 1,
          width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: 6,
        }}>×</button>
      </div>

      {/* Header row */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '28px 1fr 1fr',
        gap: 8,
        padding: '6px 16px',
        borderBottom: '1px solid rgba(0,212,170,0.08)',
        flexShrink: 0,
      }}>
        <span style={headerStyle}>#</span>
        <span style={headerStyle}>LATITUDE</span>
        <span style={headerStyle}>LONGITUDE</span>
      </div>

      {/* Points list */}
      <div style={{ overflowY: 'auto', flex: 1 }}>
        {points.length === 0 ? (
          <div style={{ padding: '20px 16px', color: 'var(--text-dim)', fontSize: 13, textAlign: 'center' }}>
            No points added yet
          </div>
        ) : (
          points.map(p => (
            <div
              key={p.id}
              onClick={() => onSelectPoint(p.id)}
              style={{
                display: 'grid',
                gridTemplateColumns: '28px 1fr 1fr',
                gap: 8,
                padding: '8px 16px',
                borderBottom: '1px solid rgba(0,212,170,0.05)',
                cursor: 'pointer',
                background: p.id === selectedPoint ? 'rgba(0,212,170,0.1)' : 'transparent',
                transition: 'background 0.1s ease',
              }}
              onMouseEnter={e => {
                if (p.id !== selectedPoint) e.currentTarget.style.background = 'rgba(0,212,170,0.05)';
              }}
              onMouseLeave={e => {
                if (p.id !== selectedPoint) e.currentTarget.style.background = 'transparent';
              }}
            >
              <div style={{
                width: 22, height: 22,
                borderRadius: '50%',
                background: p.id === selectedPoint ? 'var(--accent)' : 'var(--primary)',
                color: 'var(--bg-dark)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10,
                fontWeight: 700,
                fontFamily: 'var(--font-display)',
              }}>{p.label}</div>
              <span style={coordStyle}>{p.lat.toFixed(7)}</span>
              <span style={coordStyle}>{p.lng.toFixed(7)}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

const headerStyle: React.CSSProperties = {
  fontFamily: 'var(--font-display)',
  fontSize: 10,
  fontWeight: 700,
  color: 'var(--text-dim)',
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
};

const coordStyle: React.CSSProperties = {
  fontFamily: 'var(--font-mono)',
  fontSize: 12,
  color: 'var(--text)',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
};
