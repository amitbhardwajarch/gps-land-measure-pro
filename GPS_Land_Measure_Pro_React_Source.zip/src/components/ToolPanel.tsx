interface Props {
  hasPoints: boolean;
  hasSelected: boolean;
  onUndo: () => void;
  onDelete: () => void;
  onClear: () => void;
  onSave: () => void;
  onShowCoords: () => void;
  onShowSaved: () => void;
  coordOpen: boolean;
  savedOpen: boolean;
}

export default function ToolPanel({
  hasPoints, hasSelected,
  onUndo, onDelete, onClear, onSave,
  onShowCoords, onShowSaved,
  coordOpen, savedOpen
}: Props) {
  return (
    <div style={{
      position: 'absolute',
      right: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      zIndex: 1000,
    }}>
      <ToolBtn
        icon="↩"
        label="Undo"
        onClick={onUndo}
        disabled={!hasPoints}
        color="var(--warning)"
        title="Undo last point"
      />
      <ToolBtn
        icon="🗑"
        label="Del"
        onClick={onDelete}
        disabled={!hasSelected}
        color="var(--danger)"
        title="Delete selected point"
      />
      <ToolBtn
        icon="✕"
        label="Clear"
        onClick={onClear}
        disabled={!hasPoints}
        color="var(--danger)"
        title="Clear all points"
      />

      <div style={{ height: 1, background: 'rgba(0,212,170,0.15)', margin: '4px 0' }} />

      <ToolBtn
        icon="💾"
        label="Save"
        onClick={onSave}
        disabled={!hasPoints}
        color="var(--primary)"
        title="Save measurement"
      />
      <ToolBtn
        icon="📋"
        label="Coords"
        onClick={onShowCoords}
        disabled={!hasPoints}
        color={coordOpen ? 'var(--primary)' : undefined}
        active={coordOpen}
        title="Show coordinates"
      />
      <ToolBtn
        icon="📁"
        label="Saved"
        onClick={onShowSaved}
        color={savedOpen ? 'var(--accent2)' : undefined}
        active={savedOpen}
        title="Saved measurements"
      />
    </div>
  );
}

interface BtnProps {
  icon: string;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  color?: string;
  active?: boolean;
  title?: string;
}

function ToolBtn({ icon, label, onClick, disabled, color, active, title }: BtnProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      style={{
        width: 46,
        height: 46,
        borderRadius: 10,
        background: active ? `${color}22` : 'var(--bg-card)',
        border: `1px solid ${active ? (color ?? 'var(--border)') : 'var(--border)'}`,
        color: disabled ? 'rgba(232,244,240,0.2)' : (color ?? 'var(--text)'),
        cursor: disabled ? 'not-allowed' : 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 1,
        boxShadow: active ? `0 0 10px ${color}44` : 'var(--shadow)',
        transition: 'all 0.15s ease',
        fontFamily: 'var(--font-display)',
        fontSize: 18,
        lineHeight: 1,
      }}
    >
      <span style={{ fontSize: 18 }}>{icon}</span>
      <span style={{ fontSize: 9, letterSpacing: '0.05em', opacity: 0.7 }}>{label}</span>
    </button>
  );
}
