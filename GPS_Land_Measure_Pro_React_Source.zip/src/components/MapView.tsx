import { useEffect, useRef, useCallback } from 'react';
import L from 'leaflet';
import { Point, MapLayer } from '../types';
import { calcSides, calcAngles, formatDistance } from '../utils/geometry';

interface Props {
  points: Point[];
  mapLayer: MapLayer;
  flyTo: [number, number, number] | null;
  selectedPoint: string | null;
  onMapClick: (lat: number, lng: number) => void;
  onMarkerClick: (id: string) => void;
  onFlyComplete: () => void;
}

const TILE_LAYERS = {
  street: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '© OpenStreetMap contributors',
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '© Esri, Maxar, GeoEye',
  },
  hybrid: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '© Esri',
  },
};

const HYBRID_LABELS_URL = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

export default function MapView({
  points, mapLayer, flyTo, selectedPoint,
  onMapClick, onMarkerClick, onFlyComplete
}: Props) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const tileRef = useRef<L.TileLayer | null>(null);
  const hybridLabelRef = useRef<L.TileLayer | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  const polygonRef = useRef<L.Polygon | null>(null);
  const distLabelsRef = useRef<L.Marker[]>([]);
  const angleLabelsRef = useRef<L.Marker[]>([]);
  const polylineRef = useRef<L.Polyline | null>(null);

  // Init map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [28.4595, 77.0266], // Gurgaon default
      zoom: 14,
      zoomControl: false,
      attributionControl: true,
    });

    // Initial tile layer
    const tile = L.tileLayer(TILE_LAYERS.street.url, {
      attribution: TILE_LAYERS.street.attribution,
      maxZoom: 21,
    }).addTo(map);
    tileRef.current = tile;

    map.on('click', (e: L.LeafletMouseEvent) => {
      onMapClick(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Layer changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (tileRef.current) {
      map.removeLayer(tileRef.current);
    }
    if (hybridLabelRef.current) {
      map.removeLayer(hybridLabelRef.current);
      hybridLabelRef.current = null;
    }

    const layerCfg = TILE_LAYERS[mapLayer === 'hybrid' ? 'satellite' : mapLayer];
    const tile = L.tileLayer(layerCfg.url, {
      attribution: layerCfg.attribution,
      maxZoom: 21,
    }).addTo(map);
    tileRef.current = tile;

    if (mapLayer === 'hybrid') {
      const labelTile = L.tileLayer(HYBRID_LABELS_URL, {
        opacity: 0.5,
        maxZoom: 21,
      }).addTo(map);
      hybridLabelRef.current = labelTile;
    }
  }, [mapLayer]);

  // FlyTo
  useEffect(() => {
    if (!flyTo || !mapRef.current) return;
    const [lat, lng, zoom] = flyTo;
    mapRef.current.flyTo([lat, lng], zoom, { duration: 1.2 });
    onFlyComplete();
  }, [flyTo, onFlyComplete]);

  // Markers
  const createMarkerIcon = useCallback((label: number, isSelected: boolean) => {
    return L.divIcon({
      className: '',
      html: `<div class="measure-marker${isSelected ? ' selected' : ''}">${label}</div>`,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
    });
  }, []);

  // Render everything
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // ---- Markers ----
    const existingIds = new Set(markersRef.current.keys());
    const currentIds = new Set(points.map(p => p.id));

    // Remove stale
    existingIds.forEach(id => {
      if (!currentIds.has(id)) {
        const m = markersRef.current.get(id);
        if (m) { map.removeLayer(m); markersRef.current.delete(id); }
      }
    });

    // Add/update
    points.forEach(p => {
      const isSelected = p.id === selectedPoint;
      const icon = createMarkerIcon(p.label, isSelected);
      const existing = markersRef.current.get(p.id);
      if (existing) {
        existing.setLatLng([p.lat, p.lng]);
        existing.setIcon(icon);
      } else {
        const marker = L.marker([p.lat, p.lng], { icon, zIndexOffset: 1000 })
          .addTo(map);
        marker.on('click', (e) => {
          L.DomEvent.stopPropagation(e);
          onMarkerClick(p.id);
        });
        markersRef.current.set(p.id, marker);
      }
    });

    // ---- Polygon / Polyline ----
    if (polygonRef.current) { map.removeLayer(polygonRef.current); polygonRef.current = null; }
    if (polylineRef.current) { map.removeLayer(polylineRef.current); polylineRef.current = null; }

    if (points.length >= 3) {
      const latlngs = points.map(p => [p.lat, p.lng] as L.LatLngTuple);
      polygonRef.current = L.polygon(latlngs, {
        color: '#00d4aa',
        weight: 2,
        opacity: 0.9,
        fillColor: '#00d4aa',
        fillOpacity: 0.12,
        dashArray: undefined,
      }).addTo(map);
    } else if (points.length === 2) {
      const latlngs = points.map(p => [p.lat, p.lng] as L.LatLngTuple);
      polylineRef.current = L.polyline(latlngs, {
        color: '#00d4aa',
        weight: 2,
        opacity: 0.9,
        dashArray: '6 4',
      }).addTo(map);
    }

    // ---- Distance labels ----
    distLabelsRef.current.forEach(l => map.removeLayer(l));
    distLabelsRef.current = [];

    const sides = calcSides(points);
    sides.forEach(s => {
      const label = L.marker([s.midLat, s.midLng], {
        icon: L.divIcon({
          className: 'distance-label',
          html: formatDistance(s.distance),
          iconAnchor: [20, 10],
        }),
        interactive: false,
        zIndexOffset: 500,
      }).addTo(map);
      distLabelsRef.current.push(label);
    });

    // ---- Angle labels ----
    angleLabelsRef.current.forEach(l => map.removeLayer(l));
    angleLabelsRef.current = [];

    if (points.length >= 3) {
      const angles = calcAngles(points);
      angles.forEach(a => {
        const label = L.marker([a.lat, a.lng], {
          icon: L.divIcon({
            className: 'angle-label',
            html: `${a.angle}°`,
            iconAnchor: [-6, 22],
          }),
          interactive: false,
          zIndexOffset: 400,
        }).addTo(map);
        angleLabelsRef.current.push(label);
      });
    }
  }, [points, selectedPoint, createMarkerIcon, onMarkerClick]);

  return (
    <div
      ref={containerRef}
      style={{ position: 'absolute', inset: 0, zIndex: 0 }}
    />
  );
}
