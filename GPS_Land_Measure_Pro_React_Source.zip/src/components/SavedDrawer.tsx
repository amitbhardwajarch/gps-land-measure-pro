import { Measurement } from '../types';
import { formatArea, formatDistance } from '../utils/geometry';

interface Props {
  open: boolean;
  measurements: Measurement[];
  onClose: () => void;
  onLoad: (m: Measurement) => void;
  onDelete: (id: string) => void;
  onExport: (m: Measurement) => void;
}

export default function SavedDrawer({ open, measurements, onClose, onLoad, onDelete, onExport }: Props) {
  if (!open) return null;

  return (
    <div style={{
      position: 'absolute',
      bottom: 0, left: 0, right: 0,
      zIndex: 1100,
      background: 'var(--bg-card)',
      borderTop: '1px solid rgba(255,215,0,0.3)',
      borderRadius: '16px 16px 0 0',
      boxShadow: '0 -4px 30px rgba(0,0,0,0.5)',
      animation: 'slideUp 0.25s ease',
      maxHeight: '55vh',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 16px 10px',
        flexShrink: 0,
        borderBottom: '1px solid rgba(255,215,0,0.15)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 16 }}>📁</span>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 14,
            color: 'var(--accent2)',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
          }}>SAVED MEASUREMENTS</span>
          <span style={{
            background: 'rgba(255,215,0,0.15)',
            color: 'var(--accent2)',
            borderRadius: 6,
            padding: '1px 7px',
            fontSize: 11,
            fontWeight: 700,
            fontFamily: 'var(--font-mono)',
          }}>{measurements.length}</span>
        </div>
        <button onClick={onClose} style={{
          background: 'none', border: 'none', color: 'var(--text-dim)',
          cursor: 'pointer', fontSize: 20,
          width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>×</button>
      </div>

      {/* List */}
      <div style={{ overflowY: 'auto', flex: 1 }}>
        {measurements.length === 0 ? (
          <div style={{ padding: '30px 16px', color: 'var(--text-dim)', fontSize: 13, textAlign: 'center' }}>
            No saved measurements yet.<br />
            <span style={{ fontSize: 11, opacity: 0.6 }}>Draw a boundary and tap Save.</span>
          </div>
        ) : (
          measurements.slice().reverse().map(m => (
            <div key={m.id} style={{
              padding: '12px 16px',
              borderBottom: '1px solid rgba(0,212,170,0.06)',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: 'var(--text-bright)' }}>
                    {m.name}
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)', marginTop: 2 }}>
                    {new Date(m.timestamp).toLocaleDateString()} · {m.points.length} points
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--primary)', fontWeight: 600 }}>
                    {formatArea(m.area)}
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-dim)' }}>
                    {m.areaAcres.toFixed(3)} acres
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                <ActionBtn label="Load" color="var(--primary)" onClick={() => onLoad(m)} />
                <ActionBtn label="Export" color="var(--accent2)" onClick={() => onExport(m)} />
                <ActionBtn label="Delete" color="var(--danger)" onClick={() => onDelete(m.id)} />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function ActionBtn({ label, color, onClick }: { label: string; color: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1,
        padding: '6px 0',
        background: `${color}18`,
        border: `1px solid ${color}44`,
        borderRadius: 7,
        color,
        fontFamily: 'var(--font-display)',
        fontWeight: 600,
        fontSize: 12,
        letterSpacing: '0.04em',
        cursor: 'pointer',
        transition: 'all 0.12s ease',
      }}
      onMouseEnter={e => (e.currentTarget.style.background = `${color}30`)}
      onMouseLeave={e => (e.currentTarget.style.background = `${color}18`)}
    >
      {label}
    </button>
  );
}
