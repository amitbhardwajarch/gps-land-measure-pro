import { formatArea, formatDistance } from '../utils/geometry';

interface Props {
  area: number;
  areaAcres: number;
  perimeter: number;
  pointCount: number;
}

export default function MeasurePanel({ area, areaAcres, perimeter, pointCount }: Props) {
  return (
    <div style={{
      position: 'absolute',
      bottom: 80,
      left: 10,
      zIndex: 1000,
      background: 'var(--bg-card)',
      border: '1px solid var(--border-bright)',
      borderRadius: 14,
      padding: '12px 16px',
      minWidth: 190,
      boxShadow: 'var(--shadow), var(--shadow-glow)',
      animation: 'fadeIn 0.2s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginBottom: 10,
        borderBottom: '1px solid var(--border)',
        paddingBottom: 8,
      }}>
        <span style={{ color: 'var(--primary)', fontSize: 14 }}>◈</span>
        <span style={{
          fontFamily: 'var(--font-display)',
          fontWeight: 700,
          fontSize: 13,
          color: 'var(--primary)',
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
        }}>MEASUREMENT</span>
        <span style={{
          marginLeft: 'auto',
          background: 'var(--primary)',
          color: 'var(--bg-dark)',
          borderRadius: 6,
          padding: '1px 7px',
          fontSize: 11,
          fontWeight: 700,
          fontFamily: 'var(--font-mono)',
        }}>{pointCount} pts</span>
      </div>

      {/* Metrics */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
        <Metric label="AREA" value={formatArea(area)} highlight />
        <Metric label="ACRES" value={`${areaAcres.toFixed(4)} ac`} />
        <Metric label="HECTARES" value={`${(area / 10000).toFixed(4)} ha`} />
        <div style={{ height: 1, background: 'var(--border)', margin: '2px 0' }} />
        <Metric label="PERIMETER" value={formatDistance(perimeter)} />
      </div>
    </div>
  );
}

function Metric({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 10 }}>
      <span style={{
        fontSize: 10,
        fontFamily: 'var(--font-display)',
        letterSpacing: '0.08em',
        color: 'var(--text-dim)',
        fontWeight: 600,
        flexShrink: 0,
      }}>{label}</span>
      <span style={{
        fontFamily: 'var(--font-mono)',
        fontSize: highlight ? 14 : 12,
        fontWeight: highlight ? 700 : 500,
        color: highlight ? 'var(--primary)' : 'var(--text)',
        textAlign: 'right',
      }}>{value}</span>
    </div>
  );
}
