import { useState, useRef, useEffect } from 'react';
import { MapLayer, GeoResult } from '../types';

interface Props {
  menuOpen: boolean;
  onMenuToggle: () => void;
  onSearch: (lat: number, lng: number, zoom?: number) => void;
  mapLayer: MapLayer;
  onLayerChange: (layer: MapLayer) => void;
}

const LAYERS: { id: MapLayer; label: string; icon: string }[] = [
  { id: 'street', label: 'Street', icon: '🗺️' },
  { id: 'satellite', label: 'Satellite', icon: '🛰️' },
  { id: 'hybrid', label: 'Hybrid', icon: '🌍' },
];

export default function TopBar({ menuOpen, onMenuToggle, onSearch, mapLayer, onLayerChange }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GeoResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [layerOpen, setLayerOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const doSearch = async (q: string) => {
    if (!q.trim()) { setResults([]); setShowResults(false); return; }
    setLoading(true);
    try {
      const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
      const data: GeoResult[] = await r.json();
      setResults(data.slice(0, 5));
      setShowResults(true);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleInput = (v: string) => {
    setQuery(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => doSearch(v), 500);
  };

  const handleSelect = (r: GeoResult) => {
    onSearch(parseFloat(r.lat), parseFloat(r.lon), 17);
    setQuery(r.display_name.split(',')[0]);
    setShowResults(false);
    setResults([]);
  };

  useEffect(() => {
    const handler = () => { setShowResults(false); setLayerOpen(false); };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  return (
    <div style={{
      position: 'absolute',
      top: 0, left: 0, right: 0,
      zIndex: 1000,
      padding: '10px 12px 0',
      display: 'flex',
      gap: 8,
      alignItems: 'flex-start',
    }}>
      {/* Hamburger */}
      <button
        onClick={onMenuToggle}
        style={btnStyle}
        title="Menu"
      >
        <HamburgerIcon open={menuOpen} />
      </button>

      {/* Search bar */}
      <div style={{ flex: 1, position: 'relative' }} onClick={e => e.stopPropagation()}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius)',
          overflow: 'hidden',
          boxShadow: 'var(--shadow)',
        }}>
          <span style={{ padding: '0 10px', color: 'var(--primary)', fontSize: 16, flexShrink: 0 }}>
            {loading ? <Spinner /> : '🔍'}
          </span>
          <input
            ref={searchRef}
            value={query}
            onChange={e => handleInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && doSearch(query)}
            placeholder="Search address or place..."
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              outline: 'none',
              color: 'var(--text)',
              fontFamily: 'var(--font-display)',
              fontSize: 15,
              padding: '10px 0',
              letterSpacing: '0.02em',
            }}
          />
          {query && (
            <button onClick={() => { setQuery(''); setResults([]); setShowResults(false); }}
              style={{ padding: '0 10px', background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: 16 }}>
              ×
            </button>
          )}
        </div>

        {showResults && results.length > 0 && (
          <div style={{
            position: 'absolute',
            top: 'calc(100% + 4px)',
            left: 0, right: 0,
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            boxShadow: 'var(--shadow)',
            overflow: 'hidden',
            zIndex: 2000,
            animation: 'fadeIn 0.15s ease',
          }}>
            {results.map((r, i) => (
              <div
                key={i}
                onClick={() => handleSelect(r)}
                style={{
                  padding: '10px 14px',
                  borderBottom: i < results.length - 1 ? '1px solid rgba(0,212,170,0.08)' : 'none',
                  cursor: 'pointer',
                  fontSize: 13,
                  color: 'var(--text)',
                  lineHeight: 1.4,
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,212,170,0.08)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'none')}
              >
                <div style={{ fontWeight: 600, marginBottom: 2 }}>{r.display_name.split(',')[0]}</div>
                <div style={{ color: 'var(--text-dim)', fontSize: 11 }}>
                  {r.display_name.split(',').slice(1, 3).join(',').trim()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Layer switcher */}
      <div style={{ position: 'relative' }} onClick={e => e.stopPropagation()}>
        <button
          onClick={() => setLayerOpen(v => !v)}
          style={{
            ...btnStyle,
            fontSize: 18,
            background: layerOpen ? 'rgba(0,212,170,0.2)' : btnStyle.background,
          }}
          title="Map type"
        >
          {LAYERS.find(l => l.id === mapLayer)?.icon ?? '🗺️'}
        </button>
        {layerOpen && (
          <div style={{
            position: 'absolute',
            top: 'calc(100% + 6px)',
            right: 0,
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            overflow: 'hidden',
            boxShadow: 'var(--shadow)',
            minWidth: 130,
            animation: 'fadeIn 0.15s ease',
            zIndex: 2000,
          }}>
            {LAYERS.map(l => (
              <div
                key={l.id}
                onClick={() => { onLayerChange(l.id); setLayerOpen(false); }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '10px 14px',
                  cursor: 'pointer',
                  fontSize: 14,
                  fontFamily: 'var(--font-display)',
                  fontWeight: mapLayer === l.id ? 700 : 400,
                  color: mapLayer === l.id ? 'var(--primary)' : 'var(--text)',
                  background: mapLayer === l.id ? 'rgba(0,212,170,0.1)' : 'transparent',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,212,170,0.08)')}
                onMouseLeave={e => (e.currentTarget.style.background = mapLayer === l.id ? 'rgba(0,212,170,0.1)' : 'transparent')}
              >
                <span>{l.icon}</span> {l.label}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const btnStyle: React.CSSProperties = {
  width: 42,
  height: 42,
  borderRadius: 'var(--radius)',
  background: 'var(--bg-card)',
  border: '1px solid var(--border)',
  color: 'var(--text)',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 20,
  flexShrink: 0,
  boxShadow: 'var(--shadow)',
  transition: 'all 0.15s ease',
};

function HamburgerIcon({ open }: { open: boolean }) {
  return (
    <svg width="18" height="14" viewBox="0 0 18 14" fill="none">
      <style>{`
        .hb-line { transform-origin: 50% 50%; transition: all 0.2s ease; }
      `}</style>
      <rect className="hb-line" y={open ? "6" : "0"} x="0" width="18" height="2" rx="1"
        fill="currentColor"
        style={{ transform: open ? 'rotate(45deg) translateY(0)' : 'none', transformBox: 'fill-box' }} />
      <rect className="hb-line" y="6" x="0" width="18" height="2" rx="1"
        fill="currentColor"
        style={{ opacity: open ? 0 : 1 }} />
      <rect className="hb-line" y={open ? "6" : "12"} x="0" width="18" height="2" rx="1"
        fill="currentColor"
        style={{ transform: open ? 'rotate(-45deg)' : 'none', transformBox: 'fill-box' }} />
    </svg>
  );
}

function Spinner() {
  return (
    <span style={{
      display: 'inline-block',
      width: 14,
      height: 14,
      border: '2px solid rgba(0,212,170,0.3)',
      borderTopColor: 'var(--primary)',
      borderRadius: '50%',
      animation: 'spin 0.7s linear infinite',
    }} />
  );
}
