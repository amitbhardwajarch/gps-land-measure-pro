import { useState } from 'react';
import { formatArea } from '../utils/geometry';

interface Props {
  onSave: (name: string) => void;
  onCancel: () => void;
  pointCount: number;
  area: number;
}

export default function SaveModal({ onSave, onCancel, pointCount, area }: Props) {
  const [name, setName] = useState(`Plot ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}`);

  const handleSave = () => {
    if (name.trim()) onSave(name.trim());
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 2000,
      background: 'rgba(0,0,0,0.7)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      animation: 'fadeIn 0.15s ease',
    }}
      onClick={onCancel}
    >
      <div
        style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border-bright)',
          borderRadius: 16,
          padding: '20px',
          width: '100%',
          maxWidth: 340,
          boxShadow: 'var(--shadow), var(--shadow-glow)',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <span style={{ fontSize: 20 }}>💾</span>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 700,
            fontSize: 18,
            color: 'var(--primary)',
            letterSpacing: '0.04em',
          }}>Save Measurement</span>
        </div>

        {/* Info */}
        <div style={{
          background: 'rgba(0,212,170,0.07)',
          border: '1px solid var(--border)',
          borderRadius: 10,
          padding: '10px 14px',
          marginBottom: 16,
          display: 'flex',
          justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-dim)' }}>AREA</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--primary)', fontWeight: 600 }}>{formatArea(area)}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-dim)' }}>POINTS</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--text)', fontWeight: 600 }}>{pointCount}</div>
          </div>
        </div>

        {/* Name input */}
        <label style={{
          display: 'block',
          fontFamily: 'var(--font-display)',
          fontSize: 12,
          fontWeight: 600,
          color: 'var(--text-dim)',
          letterSpacing: '0.07em',
          marginBottom: 6,
        }}>MEASUREMENT NAME</label>
        <input
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSave()}
          autoFocus
          style={{
            width: '100%',
            background: 'rgba(0,212,170,0.05)',
            border: '1px solid var(--border-bright)',
            borderRadius: 10,
            padding: '10px 14px',
            color: 'var(--text)',
            fontFamily: 'var(--font-display)',
            fontSize: 15,
            outline: 'none',
            marginBottom: 16,
          }}
        />

        {/* Buttons */}
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={onCancel}
            style={{
              flex: 1,
              padding: '10px',
              background: 'transparent',
              border: '1px solid var(--border)',
              borderRadius: 10,
              color: 'var(--text-dim)',
              fontFamily: 'var(--font-display)',
              fontWeight: 600,
              fontSize: 14,
              cursor: 'pointer',
            }}
          >Cancel</button>
          <button
            onClick={handleSave}
            disabled={!name.trim()}
            style={{
              flex: 2,
              padding: '10px',
              background: 'var(--primary)',
              border: 'none',
              borderRadius: 10,
              color: 'var(--bg-dark)',
              fontFamily: 'var(--font-display)',
              fontWeight: 700,
              fontSize: 14,
              cursor: 'pointer',
              letterSpacing: '0.04em',
            }}
          >Save Measurement</button>
        </div>
      </div>
    </div>
  );
}
