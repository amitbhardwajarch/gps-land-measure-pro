import { useState, useCallback } from 'react';
import MapView from './components/MapView';
import TopBar from './components/TopBar';
import ToolPanel from './components/ToolPanel';
import MeasurePanel from './components/MeasurePanel';
import CoordDrawer from './components/CoordDrawer';
import SavedDrawer from './components/SavedDrawer';
import SaveModal from './components/SaveModal';
import { Point, MapLayer, Measurement } from './types';
import { calcArea, calcPerimeter, generateId } from './utils/geometry';
import { saveMeasurements, loadMeasurements, exportReport, deleteMeasurement } from './utils/storage';

export default function App() {
  const [points, setPoints] = useState<Point[]>([]);
  const [mapLayer, setMapLayer] = useState<MapLayer>('street');
  const [flyTo, setFlyTo] = useState<[number, number, number] | null>(null);
  const [coordOpen, setCoordOpen] = useState(false);
  const [savedOpen, setSavedOpen] = useState(false);
  const [saveModal, setSaveModal] = useState(false);
  const [savedList, setSavedList] = useState<Measurement[]>(loadMeasurements);
  const [selectedPoint, setSelectedPoint] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const { area, areaAcres } = calcArea(points);
  const perimeter = calcPerimeter(points);

  const handleMapClick = useCallback((lat: number, lng: number) => {
    setPoints(prev => [
      ...prev,
      { id: generateId(), lat, lng, label: prev.length + 1 }
    ]);
  }, []);

  const handleUndo = () => {
    setPoints(prev => prev.slice(0, -1));
    setSelectedPoint(null);
  };

  const handleDelete = () => {
    if (!selectedPoint) return;
    setPoints(prev => {
      const filtered = prev.filter(p => p.id !== selectedPoint);
      return filtered.map((p, i) => ({ ...p, label: i + 1 }));
    });
    setSelectedPoint(null);
  };

  const handleClear = () => {
    setPoints([]);
    setSelectedPoint(null);
  };

  const handleSearch = (lat: number, lng: number, zoom = 17) => {
    setFlyTo([lat, lng, zoom]);
  };

  const handleSave = (name: string) => {
    const m: Measurement = {
      id: generateId(),
      name,
      points,
      area,
      areaAcres,
      perimeter,
      timestamp: Date.now()
    };
    const updated = [...savedList, m];
    setSavedList(updated);
    saveMeasurements(updated);
    setSaveModal(false);
  };

  const handleDeleteSaved = (id: string) => {
    setSavedList(deleteMeasurement(id));
  };

  const handleLoadSaved = (m: Measurement) => {
    setPoints(m.points);
    setSavedOpen(false);
    if (m.points.length > 0) {
      const midLat = m.points.reduce((a, p) => a + p.lat, 0) / m.points.length;
      const midLng = m.points.reduce((a, p) => a + p.lng, 0) / m.points.length;
      setFlyTo([midLat, midLng, 16]);
    }
  };

  const handleExport = (m: Measurement) => exportReport(m);

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100dvh', overflow: 'hidden' }}>
      {/* Map fills everything */}
      <MapView
        points={points}
        mapLayer={mapLayer}
        flyTo={flyTo}
        selectedPoint={selectedPoint}
        onMapClick={handleMapClick}
        onMarkerClick={(id) => setSelectedPoint(prev => prev === id ? null : id)}
        onFlyComplete={() => setFlyTo(null)}
      />

      {/* Top bar: hamburger + search */}
      <TopBar
        menuOpen={menuOpen}
        onMenuToggle={() => setMenuOpen(v => !v)}
        onSearch={handleSearch}
        mapLayer={mapLayer}
        onLayerChange={setMapLayer}
      />

      {/* Right-side tool buttons */}
      <ToolPanel
        hasPoints={points.length > 0}
        hasSelected={!!selectedPoint}
        onUndo={handleUndo}
        onDelete={handleDelete}
        onClear={handleClear}
        onSave={() => setSaveModal(true)}
        onShowCoords={() => setCoordOpen(v => !v)}
        onShowSaved={() => setSavedOpen(v => !v)}
        coordOpen={coordOpen}
        savedOpen={savedOpen}
      />

      {/* Floating measurement result */}
      {points.length >= 2 && (
        <MeasurePanel
          area={area}
          areaAcres={areaAcres}
          perimeter={perimeter}
          pointCount={points.length}
        />
      )}

      {/* Bottom coordinate drawer */}
      <CoordDrawer
        points={points}
        open={coordOpen}
        selectedPoint={selectedPoint}
        onSelectPoint={setSelectedPoint}
        onClose={() => setCoordOpen(false)}
      />

      {/* Saved measurements drawer */}
      <SavedDrawer
        open={savedOpen}
        measurements={savedList}
        onClose={() => setSavedOpen(false)}
        onLoad={handleLoadSaved}
        onDelete={handleDeleteSaved}
        onExport={handleExport}
      />

      {/* Save modal */}
      {saveModal && (
        <SaveModal
          onSave={handleSave}
          onCancel={() => setSaveModal(false)}
          pointCount={points.length}
          area={area}
        />
      )}

      {/* Tap-to-add hint */}
      {points.length === 0 && (
        <div style={{
          position: 'absolute',
          bottom: 80,
          left: '50%',
          transform: 'translateX(-50%)',
          background: 'rgba(10,14,26,0.85)',
          border: '1px solid rgba(0,212,170,0.3)',
          borderRadius: 10,
          padding: '10px 18px',
          color: 'rgba(232,244,240,0.7)',
          fontFamily: 'var(--font-display)',
          fontSize: 14,
          letterSpacing: '0.03em',
          pointerEvents: 'none',
          zIndex: 900,
          textAlign: 'center',
          whiteSpace: 'nowrap',
        }}>
          📍 Tap the map to add boundary points
        </div>
      )}
    </div>
  );
}
