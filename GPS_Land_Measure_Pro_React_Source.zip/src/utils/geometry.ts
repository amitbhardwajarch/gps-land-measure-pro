import * as turf from '@turf/turf';
import { Point, SideInfo, AngleInfo } from '../types';

export function calcArea(points: Point[]): { area: number; areaAcres: number } {
  if (points.length < 3) return { area: 0, areaAcres: 0 };
  const coords = [...points.map(p => [p.lng, p.lat]), [points[0].lng, points[0].lat]];
  const polygon = turf.polygon([coords]);
  const areaSqM = turf.area(polygon);
  const areaSqFt = areaSqM * 10.7639;
  const areaAcres = areaSqM / 4046.856;
  return { area: areaSqM, areaAcres };
}

export function calcPerimeter(points: Point[]): number {
  if (points.length < 2) return 0;
  let total = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i];
    const b = points[(i + 1) % points.length];
    const from = turf.point([a.lng, a.lat]);
    const to = turf.point([b.lng, b.lat]);
    total += turf.distance(from, to, { units: 'meters' });
  }
  return total;
}

export function calcSides(points: Point[]): SideInfo[] {
  if (points.length < 2) return [];
  const sides: SideInfo[] = [];
  for (let i = 0; i < points.length; i++) {
    const a = points[i];
    const b = points[(i + 1) % points.length];
    if (points.length < 3 && i === points.length - 1) break;
    const from = turf.point([a.lng, a.lat]);
    const to = turf.point([b.lng, b.lat]);
    const dist = turf.distance(from, to, { units: 'meters' });
    sides.push({
      distance: dist,
      midLat: (a.lat + b.lat) / 2,
      midLng: (a.lng + b.lng) / 2,
    });
  }
  return sides;
}

export function calcAngles(points: Point[]): AngleInfo[] {
  if (points.length < 3) return [];
  const angles: AngleInfo[] = [];
  for (let i = 0; i < points.length; i++) {
    const prev = points[(i - 1 + points.length) % points.length];
    const curr = points[i];
    const next = points[(i + 1) % points.length];
    const v1 = { x: prev.lng - curr.lng, y: prev.lat - curr.lat };
    const v2 = { x: next.lng - curr.lng, y: next.lat - curr.lat };
    const dot = v1.x * v2.x + v1.y * v2.y;
    const mag1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y);
    const mag2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y);
    if (mag1 === 0 || mag2 === 0) continue;
    const cosAngle = Math.max(-1, Math.min(1, dot / (mag1 * mag2)));
    const angle = (Math.acos(cosAngle) * 180) / Math.PI;
    angles.push({ angle: Math.round(angle * 10) / 10, lat: curr.lat, lng: curr.lng });
  }
  return angles;
}

export function formatDistance(meters: number): string {
  if (meters >= 1000) return `${(meters / 1000).toFixed(2)} km`;
  if (meters >= 1) return `${meters.toFixed(1)} m`;
  return `${(meters * 100).toFixed(0)} cm`;
}

export function formatArea(sqm: number): string {
  if (sqm >= 1000000) return `${(sqm / 1000000).toFixed(4)} km²`;
  if (sqm >= 10000) return `${(sqm / 10000).toFixed(4)} ha`;
  return `${sqm.toFixed(2)} m²`;
}

export function generateId(): string {
  return Math.random().toString(36).slice(2, 10);
}
