export interface Point {
  id: string;
  lat: number;
  lng: number;
  label: number;
}

export interface Measurement {
  id: string;
  name: string;
  points: Point[];
  area: number;
  areaAcres: number;
  perimeter: number;
  timestamp: number;
}

export type MapLayer = 'street' | 'satellite' | 'hybrid';

export interface GeoResult {
  lat: string;
  lon: string;
  display_name: string;
  boundingbox?: string[];
}

export interface SideInfo {
  distance: number;
  midLat: number;
  midLng: number;
}

export interface AngleInfo {
  angle: number;
  lat: number;
  lng: number;
}
